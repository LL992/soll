package com.koreait.onnet.model;

public class CodeVO {
	private int i_m;
	private int cd;
	private String val;

	public int getI_m() {
		return i_m;
	}
	public void setI_m(int i_m) {
		this.i_m = i_m;
	}
	public int getCd() {
		return cd;
	}
	public void setCd(int cd) {
		this.cd = cd;
	}
	public String getVal() {
		return val;
	}
	public void setVal(String val) {
		this.val = val;
	}
}