package com.koreait.onnet.user.model;

public class UserDTO extends UserVO {

}
